const { Kafka} =require('kafkajs')

const kafka=new Kafka({
    clientId: 'my-app',
    brokers: ['127.0.0.1:9092','127.0.0.1:9092']
})

const consumer=kafka.consumer({groupId: 'test-group'})

async function createConsumer(){
    await consumer.connect();
    await consumer.subscribe({
        topic:'vivek',
        fromBeginning: true,
    })
    await consumer.run({
        eachMessage:async({topic,partition,message})=>{
            console.log({
                value:message.value.toString()
            })
        }
    })
}

createConsumer()