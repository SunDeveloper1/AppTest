const { Kafka} =require('kafkajs')

const kafka=new Kafka({
    clientId: 'my-app',
    brokers: ['127.0.0.1:9092','127.0.0.1:9092']
})

async function createProducer(){

const producer=kafka.producer();

await producer.connect();

await producer.send({
    topic:'vivek',
    messages:[
        {value:'newProducer!'}
    ]
})

await producer.disconnect();

}


createProducer();